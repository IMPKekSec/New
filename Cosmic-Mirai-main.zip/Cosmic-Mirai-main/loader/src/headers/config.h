#pragma once

#define HTTP_SERVER "138.197.67.36"
#define HTTP_PORT 80

#define TFTP_SERVER "138.197.67.36"
